﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sistema.Clases
{
    internal class clUsuarios
    {
        public int USU_ID;
        private string USU_LOGIN;
        private string USU_PASS;
        public string USU_NOMBRE;
        public byte USU_ROL;

        public clUsuarios(string uSU_LOGIN, string uSU_PASS)
        {
            USU_LOGIN = uSU_LOGIN;
            USU_PASS = uSU_PASS;
        }
        //Metodo constructor para grabar y modificar
        public clUsuarios(int uSU_ID, string uSU_LOGIN, string uSU_PASS, string uSU_NOMBRE, byte uSU_ROL)
        {
            USU_ID = uSU_ID;
            USU_LOGIN = uSU_LOGIN;
            USU_PASS = uSU_PASS;
            USU_NOMBRE = uSU_NOMBRE;
            USU_ROL = uSU_ROL;
        }
        //Metodo constructor busqueda de toda la informacion de la tabla de usuarios
        public clUsuarios()
        {

        }
        //método constructor para consulta individual
        public clUsuarios(int uSU_ID)
        {
            USU_ID = uSU_ID;
        }

        public string CONSULTARI()
        {
            return ("SELECT NOMBRE_P,COTRASEÑA_P FROM USUARIO_PRUEBA WHERE USUARIO_P= '" + this.USU_LOGIN + "' and COTRASEÑA_P = dbo.MD5('" + this.USU_PASS + "')");
        }
        public string consultageneral()
        {
            return ("SELECT * FROM ");
        }
        public string GRABAR()
        {
            return (" insert into USUARIO_PRUEBA values ('" + this.USU_ID + "','" + this.USU_LOGIN + "','" + this.USU_NOMBRE + "','" + this.USU_PASS + "','" + this.USU_ROL + "')");
        }
        public string CONSULTAR2()
        {
            return (" SELECT * FROM USUARIO_PRUEBA WHERE ID_P= '" + this.USU_ID + "'");
        }
        public string modificar()
        {
            return (" update USUARIO_PRUEBA set USUARIO_P ='" + this.USU_LOGIN + "', NOMBRE_P ='" + this.USU_NOMBRE +"', COTRASEÑA_P ='" + this.USU_PASS + "', ID_ROL_P = '" + this.USU_ROL + "' WHERE ID_P= '" + this.USU_ID + "'");
        }
        public string consultageneral2()
        {
            return (" SELECT ID_P as ID_P,USUARIO_P as USUARIO_P,NOMBRE_P as NOMBRE_P,COTRASEÑA_P as COTRASEÑA_P,ID_ROL_P as ID_ROL_P FROM USUARIO_PRUEBA");
        }
        public string consecutivo()
        {
            return ("SELECT COUNT(*) + 1 AS FOLIO FROM USUARIO_PRUEBA");
        }
    }
}
