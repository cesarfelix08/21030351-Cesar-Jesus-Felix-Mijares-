﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clsRoles
    {
        private byte id;
        private string descripcion;

        // Método Constructor Busqueda de toda la informacion de la tabla de Roles
        public clsRoles()
        {

        }
        // método constructor para grabar y modificar
        public clsRoles(byte id, string descripcion)
        {
            this.id = id;
            this.descripcion = descripcion;
        }
        // método constructor para consulta individual
        public clsRoles(byte id)
        {
            this.id = id;
        }

        public string GRABAR()
        {
            return (" insert into TBLROLES values ('" + this.id + "','" + this.descripcion + "')");
        }
        public string CONSULTARI()
        {
            return (" SELECT * FROM  TBLROLES WHERE id= '" + this.id + "'");
        }
        public string modificar()
        {
            return (" update TBLROLES set  descripcion ='" + this.descripcion + "' WHERE id= '" + this.id + "'");
        }
        public string consultageneral()
        {
            return (" SELECT id as id,descripcion as descripcion FROM  TBLROLES");
        }
        public string consecutivo()
        {
            return ("SELECT COUNT(*) + 1 AS FOLIO FROM TBLROLES");
        }
    }
}
