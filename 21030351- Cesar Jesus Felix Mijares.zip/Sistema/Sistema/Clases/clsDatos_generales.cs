﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clsDatos_generales
    {
        private string nombre_empresa;
        private string direccion;
        private string telefono;
        private string gerente;

        // método Constructor Busqueda de toda la informacion de la tabla Datos generales
        public clsDatos_generales()
        {

        }
        // método constructor para grabar y modificar
        public clsDatos_generales(string nombre_empresa, string direccion, string telefono, string gerente)
        {
            this.nombre_empresa = nombre_empresa;
            this.direccion = direccion;
            this.telefono = telefono;
            this.gerente = gerente;
        }
        // método constructor para consulta individual
        public clsDatos_generales(string nombre_empresa)
        {
            this.nombre_empresa = nombre_empresa;
        }

        public string GRABAR()
        {
            return (" insert into TBLDATOS_GENERALES values ('" + this.nombre_empresa + "','" + this.direccion + "','" + this.telefono + "','" + this.gerente + "')");
        }
        public string CONSULTARI()
        {
            return (" SELECT * FROM  TBLDATOS_GENERALES WHERE Nombre_empresa= '" + this.nombre_empresa + "'");
        }
        public string modificar()
        {
            return (" update TBLDATOS_GENERALES set Direccion ='" + this.direccion + "', telefono ='" + this.telefono + "', Gerente ='" + this.gerente +"' WHERE Nombre_empresa= '" + this.nombre_empresa + "'");
        }
        public string consultageneral()
        {
            return (" SELECT Nombre_empresa as Nombre_empresa,Direccion as Direccion,Telefono as Telefono,Gerente as Gerente FROM TBLDATOS_GENERALES");
        }
        public string consecutivo()
        {
            return ("SELECT Nombre_empresa as Nombre_empresa,Direccion as Direccion,Telefono as Telefono,Gerente as Gerente FROM TBLDATOS_GENERALES");
        }
    }
}
