﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    public static class globales
    {
        static public string dbn = "PRUEBA2";
        static public string server = "CE";
        static public string password = "123456789";
        static public string seguridad = "Integrated Security=True";
        static public string userID = "sa";

        static public string miconexion = @"Data Source = " + server + "; Initial Catalog = " + dbn + "; Persist Security info = True; User ID = sa; Password = " + password;

        static public byte nivel = 0;
        static public bool nive = false;
        static public string lusuario = "";
        static public string lnombre = "";
        static public string lpuesto = "";

    }
}
