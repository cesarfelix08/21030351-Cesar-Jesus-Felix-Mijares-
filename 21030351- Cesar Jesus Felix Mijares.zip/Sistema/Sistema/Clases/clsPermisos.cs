﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clsPermisos
    {
        private int id;
        private byte id_rol;
        private byte id_modulo;
        private bool consultar;
        private bool grabar;
        private bool actualizar;
        private bool eliminar;

        // Método Constructor Busqueda de toda la informacion de la tabla de Permisos
        public clsPermisos()
        {

        }
        // método constructor para grabar y modificar
        public clsPermisos( byte id_rol, byte id_modulo, bool consultar, bool grabar, bool actualizar, bool eliminar)
        {
            this.id_rol = id_rol;
            this.id_modulo = id_modulo;
            this.consultar = consultar;
            this.grabar = grabar;
            this.actualizar = actualizar;
            this.eliminar = eliminar;
        }
        // método constructor para consulta individual
        public clsPermisos(int id)
        {
            this.id = id;
            //this.id_rol = id_rol;
            //this.id_modulo = id_modulo;
        }

        public string GRABAR()
        {
            return (" insert into TBLPERMISOS values ('" + this.id_rol + "','" + this.id_modulo + "','" + this.consultar + "','" + this.grabar + "','" + this.actualizar + "','" + this.eliminar + "')");
        }
        public string CONSULTARI()
        {
            return (" SELECT * FROM  TBLROLES WHERE Id = '" + this.id + "'");
        }
        public string modificar()
        {
            return (" update TBLPERMISOS set Id_rol ='" + this.id_rol + "', Id_modulo ='" + this.id_modulo + "', consultar ='" + this.consultar + "','" + this.grabar + "','" + this.actualizar + "','" + this.eliminar + "' WHERE Id= '" + this.id + "'");
        }
        public string consultageneral()
        {
            return (" SELECT Id as Id,Id_rol as Id_rol,Id_modulo as Id_modulo,consultar as consultar,grabar as grabar,actualizar as actualizar,eliminar as eliminar FROM TBLPERMISOS");
        }
        public string consecutivo()
        {
            return ("SELECT COUNT(*) + 1 AS FOLIO FROM TBLPERMISOS");
        }
    }
}
