﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clsModulos
    {
        private byte id_modulo;
        private string nombre_modulo;

        // Método Constructor Busqueda de toda la informacion de la tabla de Modulos
        public clsModulos()
        {

        }
        // método constructor para grabar y modificar
        public clsModulos(byte id_modulo, string nombre_modulo)
        {
            this.id_modulo = id_modulo;
            this.nombre_modulo = nombre_modulo;
        }
        // método constructor para consulta individual
        public clsModulos(byte id_modulo)
        {
            this.id_modulo = id_modulo;
        }

        public string GRABAR()
        {
            return (" insert into TBLMODULOS values ('" + this.id_modulo + "','" + this.nombre_modulo + "')");
        }
        public string CONSULTARI()
        {
            return (" SELECT * FROM  TBLMODULOS WHERE id_modulo= '" + this.id_modulo + "'");
        }
        public string modificar()
        {
            return (" update TBLMODULOS set nombre_modulo ='" + this.nombre_modulo + "' WHERE id_modulo = '" + this.id_modulo + "'");
        }
        public string consultageneral()
        {
            return (" SELECT id_modulo as id_modulo, nombre_modulo as nombre_modulo FROM TBLMODULOS");
        }
        public string consecutivo()
        {
            return ("SELECT COUNT(*) + 1 AS FOLIO FROM TBLMODULOS");
        }
    }
}
