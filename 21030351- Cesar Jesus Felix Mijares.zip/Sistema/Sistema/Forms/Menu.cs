﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void rOLESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmRoles x = new Forms.frmRoles();
            x.Show();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mODULOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmModulos x = new Forms.frmModulos();
            x.Show();
        }

        private void uSUARIOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsuarios x = new frmUsuarios();
            x.Show();
        }

        private void dATOSGENERALESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmDatos_Generales x = new Forms.frmDatos_Generales();
            x.Show();
        }
    }
}