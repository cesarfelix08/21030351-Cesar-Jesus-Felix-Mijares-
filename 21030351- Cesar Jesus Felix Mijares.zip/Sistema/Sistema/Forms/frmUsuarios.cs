﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema
{
    public partial class frmUsuarios : Form
    {
        public frmUsuarios()
        {
            InitializeComponent();
        }

        private void frmUsuarios_Load(object sender, EventArgs e)
        {
            cargarroles();
            cargarfolio();
        }
        private void cargarroles()
        {
            DataSet ds = new DataSet();
            Clases.clsRoles s = new Clases.clsRoles();
            Clases.conexion c = new Clases.conexion(s.consultageneral());
            ds = c.consultar();
            cmbroles.DataSource = ds.Tables[0];
            cmbroles.DisplayMember = ds.Tables[0].Columns["descripcion"].ToString();
            cmbroles.ValueMember = ds.Tables[0].Columns["id"].ToString();

        }
        Clases.clUsuarios G;
        private void busca()
        {
            try
            {
                G = new Clases.clUsuarios();
                Clases.conexion con = new Clases.conexion();
                if (con.Execute(G.consultageneral2(), 0) == true)
                {
                    if (con.FieldValue != "")
                    {
                        TXTCLAVE.Text = con.FieldValue;
                        consultar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }
        Clases.conexion c;
        Clases.clUsuarios B;
        private void consultar()
        {
            if (!(TXTCLAVE.Text == ""))
            {
                try
                {
                    Clases.clUsuarios B = new Clases.clUsuarios(Convert.ToInt32(TXTCLAVE.Text));
                    DataSet ds = new DataSet();
                    c = new Clases.conexion(B.CONSULTAR2());
                    ds = c.consultar();
                    if (ds.Tables["Tabla"].Rows.Count > 0)
                    {
                        TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["ID_P"].ToString();
                        TXTUSUARIO.Text = ds.Tables["Tabla"].Rows[0]["USUARIO_P"].ToString();
                        TXTCONTRASEÑA.Text = ds.Tables["Tabla"].Rows[0]["COTRASEÑA_P"].ToString();
                        TXTNOMBREUSUA.Text = ds.Tables["Tabla"].Rows[0]["NOMBRE_P"].ToString();
                        cmbroles.DisplayMember = ds.Tables["Tabla"].Rows[0]["ID_ROL_P"].ToString();

                    }
                    else

                        MessageBox.Show("No Existe este dato");
                    TXTCLAVE.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex.Message);
                }

            }
        }

        private void graba()
        {
            Clases.clUsuarios B = new Clases.clUsuarios(Convert.ToInt32(TXTCLAVE.Text));
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.CONSULTAR2());
            ds = c.consultar();
            G = new Clases.clUsuarios(Convert.ToInt32(TXTCLAVE.Text), TXTUSUARIO.Text, Clases.clsEncripcion.Encrypt.GetMD5(TXTCONTRASEÑA.Text), TXTNOMBREUSUA.Text, byte.Parse(cmbroles.SelectedValue.ToString()));
            if (ds.Tables["Tabla"].Rows.Count > 0)
                c = new Clases.conexion(G.modificar());
            else
                c = new Clases.conexion(G.GRABAR());
            MessageBox.Show(c.ejecutar());
        }
        private void cargarfolio()
        {
            B = new Clases.clUsuarios();
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.consecutivo());
            ds = c.consultar();
            if (ds.Tables["Tabla"].Rows.Count > 0)
            {
                TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["FOLIO"].ToString();
            }
        }
        private void limpiar()
        {
            TXTUSUARIO.Clear();
            TXTCONTRASEÑA.Clear();
            TXTCONFIRCONTRA.Clear();
            TXTNOMBREUSUA.Clear();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            if ((TXTUSUARIO.Text == "") || (TXTCONTRASEÑA.Text == "") || (TXTNOMBREUSUA.Text == "") || (TXTCONFIRCONTRA.Text == ""))
            {
                MessageBox.Show("Faltan datos por rellenar");
            }
            else
            {
                if (TXTCONFIRCONTRA.Text != TXTCONTRASEÑA.Text)
                {
                    MessageBox.Show("Las contraseñas no coinciden");
                }
                else
                {
                    graba();
                    cargarfolio();
                    limpiar();
                }
            }
        }

        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
            busca();
        }

        private void toolStripButton5_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        //byte rol = 0;
        //rol = byte.Parse(cmbroles.SelectedValue.ToString());
    }
}
